//
//  sdkTEST.h
//  sdkTEST
//
//  Created by SergeyBrazhnik on 10.11.2020.
//

#import <Foundation/Foundation.h>

//! Project version number for sdkTEST.
FOUNDATION_EXPORT double sdkTESTVersionNumber;

//! Project version string for sdkTEST.
FOUNDATION_EXPORT const unsigned char sdkTESTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <sdkTEST/PublicHeader.h>


