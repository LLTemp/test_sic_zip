//
//  test_sic.h
//  test_sic
//
//  Created by SergeyBrazhnik on 09.11.2020.
//

#import <Foundation/Foundation.h>

//! Project version number for test_sic.
FOUNDATION_EXPORT double test_sicVersionNumber;

//! Project version string for test_sic.
FOUNDATION_EXPORT const unsigned char test_sicVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <test_sic/PublicHeader.h>


